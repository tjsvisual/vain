<?php
$this->title = "Location - Country, State, City";
?>
<div class="card">
    <div class="row" style="padding-top:100px;padding-bottom:150px;">
        <div class="col-lg-8 col-lg-push-2">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <strong>
                        <i class="fa fa-pencil"></i> SubType/Brand
                    </strong>
                </div>
                <div class="panel-body">


                </div>
            </div>
        </div>
    </div>
</div>
