<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Ad sense';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="row">



</div>

